package com.orca.bookclub.controllers;


import com.orca.bookclub.models.Book;
import com.orca.bookclub.models.User;
import com.orca.bookclub.services.BookService;
import com.orca.bookclub.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Controller
public class BookController {
    @Autowired
    BookService bookService;
    @Autowired
    UserService userService;



    @GetMapping("/newbook")
    public String newbook(HttpSession session, Model model, @ModelAttribute("book") Book book) {
        User user = userService.findById((Long) session.getAttribute("userId"));
        model.addAttribute("user", user);
        return "newbook.jsp";

    }

    // create new book
    @PostMapping("/addbook")
    public String createbook(HttpSession session, Model model, @Valid @ModelAttribute("book") Book book, BindingResult result){
        if (result.hasErrors()){
            return "newbook.jsp";
        }
        else{
            User user = userService.findById((Long) session.getAttribute("userId"));
            List<User> users = new ArrayList<>();
            users.add(user);
            model.addAttribute("users", users);
            bookService.save(book);
            return "redirect:/dashboard";
        }
    }
// Show book into
    @GetMapping("/book/{id}")
    public String bookinfo(HttpSession session, Model model, @PathVariable("id") Long id){
        Book book = bookService.findBook(id);
        User user = userService.findById((Long) session.getAttribute("userId"));
        model.addAttribute("book", book);
        model.addAttribute("user", user);
        return "bookinfo.jsp";
    }
// Edit book info
    @GetMapping("/edit/{id}")
    public String edit(Model model, HttpSession session, @PathVariable("id") Long id) {
        Book book = bookService.findBook(id);
        User user = userService.findById((Long) session.getAttribute("userId"));
        model.addAttribute("user", user);
        model.addAttribute("book", book);
        return "edit.jsp";
    }
// Updating book info
    @PutMapping("/update/{id}")
    public String update(@Valid @ModelAttribute("book") Book book,BindingResult result){
        if (result.hasErrors()){
            return "edit.jsp";
        }
        bookService.save(book);
        return "redirect:/book/{id}";
    }
    // DELETE THEM
    @DeleteMapping("/delete/{id}")
    public String destroy(@PathVariable("id") Long id) {
        Book book = bookService.findBook(id);
        bookService.delete(book);
        return "redirect:/dashboard";
    }
    // like
    @GetMapping("/books/like/{id}")
    public String like(
            HttpSession session,
            @PathVariable("id") Long id){
        Book book = bookService.findBook(id);
        User user = userService.findById((Long) session.getAttribute("userId"));
        book.getUsers().add(user);
        bookService.save(book);
        return "redirect:/dashboard";
    }

    @GetMapping("/books/unlike/{id}")
    public String unlike(
            HttpSession session,
            @PathVariable("id") Long id){
        Book book = bookService.findBook(id);
        User user = userService.findById((Long) session.getAttribute("userId"));
        book.getUsers().remove(user);
        bookService.save(book);
        return "redirect:/dashboard";
    }


}
